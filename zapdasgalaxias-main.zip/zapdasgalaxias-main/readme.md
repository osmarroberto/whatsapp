# BOT ZDG

Olá, essa é uma implementação da biblioteca <a href="https://github.com/pedroslopez/whatsapp-web.js">whatsapp-web.js</a>

Conheça o canal do Zap das Galáxias:

- <a href="https://www.youtube.com/channel/UCrPbAoQKz42Gm0mLdWatAEA">Zap das Galáxias</a>


### Como usar?

- git clone https://github.com/pedroherpeto/zapdasgalaxias.git
- cd zapdasgalaxias
- Rodar `npm install`
- Rodar `npm start`
- Abrir o browser no endereço `http://localhost:8000`
- Ler o QRCode na tela


## Conheça a Comunidade ZDG

🤑 Garanta sua renda extra explorando todo o poder da API do WhatsApp de graça, mesmo que você nao seja programador, clicando no link <a href="https://zapdasgalaxias.com.br">Zap das Galáxias</a>. Obrigado =)
